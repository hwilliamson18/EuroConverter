class Main {
  public static void main(String[] args) {
    double Euro= 3;
    double conversion = 1.18;
    double total= Euro * conversion;
    System.out.println("If you have "+ Euro +" Euros. Your total in US dollars is $" + total);

  }
}